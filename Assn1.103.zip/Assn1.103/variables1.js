// 20 different variables an display them on the HTML
var name="Class Assignment 1";
var description="Create a program";
var points= 6.6;
var due ="01/25/2021";
var name2="Class Assignment 2";
var description2="Create a program 2";
var points2= 6.62;
var due2 ="01/27/2021";
var name3="Class Assignment 3";
var description3="Create a program 3";
var points3= 6.63;
var due3 ="01/29/2021";
var name4="Class Assignment 4";
var description4="Create a program 4";
var points4= 6.64;
var due4 ="01/30/2021";
var name5="Class Assignment 5";
var description5="Create a program 5";
var points5= 6.65;
var due5 ="01/31/2021";




//('<h1> ${name} </h1> <p class="borderclass"> ${description} </p> <p>Points: ${points}</p> <p>Due Date: ${due}</p>');

document.write(`<h1> ${name} </h1> 
 <p class="borderclass"> ${description} </p>
 <p>Points: ${points}</p>
 <p>Due Date: ${due}</p>`);
 
 document.write(`<h1> ${name2} </h1> 
 <p class="borderclass"> ${description2} </p>
 <p>Points: ${points2}</p>
 <p>Due Date: ${due2}</p>`);

 document.write(`<h1> ${name3} </h1> 
 <p class="borderclass"> ${description3} </p>
 <p>Points: ${points3}</p>
 <p>Due Date: ${due3}</p>`);

 document.write(`<h1> ${name4} </h1> 
 <p class="borderclass"> ${description4} </p>
 <p>Points: ${points4}</p>
 <p>Due Date: ${due4}</p>`);

 document.write(`<h1> ${name5} </h1> 
 <p class="borderclass"> ${description5} </p>
 <p>Points: ${points5}</p>
 <p>Due Date: ${due5}</p>`);
