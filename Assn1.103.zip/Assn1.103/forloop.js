//a for loop and display the numbers from 1 to 100, 2 by 2
for(var x=0;x<=100;x+=2){
    document.write("Line"+ x + "</br>");
}