//one script with an if statement

var yourGrade=90;
var passGrade=70;

if(passGrade<yourGrade){
    document.write(" Congratulations! You passed!!");
}else if (yourGrade<passGrade){
    document.write("You didn't quite make it!");
}